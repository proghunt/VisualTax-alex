unit REST.Clouds;

interface
uses
  System.Classes,
  System.SysUtils,
  System.StrUtils,
  System.Variants,
  System.TypInfo,
  System.IOUtils,
  System.Generics.Collections,
  IdLogEvent,
  IdHTTP,
  IdURI,
  IdHeaderList,
  IdSSLOpenSSL,
  XSuperObject,
  REST.Client,
  REST.Types,
  REST.Authenticator.OAuth,
  OAuthWebForm,
  REST.Utils,
  System.JSON;

type
{$region 'REST'}

  TResponseMetadata = record
  end;

  TRequestChilds = record
  end;
{$endregion 'REST'}


  TOAuth2ResponseType = REST.Authenticator.OAuth.TOAuth2ResponseType;

  TIdHTTP = class(IdHTTP.TIdHTTP)
  end;

  TOnFindToken = reference to function (AURL: String): Boolean;

  TRESTClient = class
  public type
    TMethod = (GET, POST, PUT, DELETE, PATCH);
    TURI = record
      class operator Implicit(const Value: string): TURI;
      class operator Explicit(const Value: string): TURI;
      class operator Add(const A: TURI; B: string): TURI;
    private
      FURI : string;
      FParams: TArray<TPair<string, string>>;
      function getURI: string;
    public
      procedure AddParam(const AName, AValue: string);
      procedure SetParam(const AName, AValue: string);
      procedure AddPath (const APath: string);
      property  URI: string read getURI;
    end;
  private
    FIdHTTP: TIdHTTP;
    FLastError : string;
    FAuthCode: string;
    FNeedAuthorize: Boolean;
  private
    FAuthorizeParams: TStrings;
    FOnFindToken : TOnFindToken;
    procedure setAuthCode(const Value: string);
    function  getCustomHeaders: TIdHeaderList;
    function  getContentType: string;
    procedure setContentType(const AValue: string);
    function  JSonToStream(const AJSon: ISuperObject): TStream;
    function  StreamToJSon(AStream: TStream): ISuperObject;

    procedure OAuth2_DropBox_OnAfterRedirect(const AURL: string; var DoCloseWebView : boolean);
    procedure OAuth2_DropBox_OnFailLoadWithError(ASender: TObject; StatusCode: OleVariant; var Cancel: Boolean);
    procedure OAuth2_GoogleDrive_BrowserTitleChanged(const ATitle: string; var DoCloseWebView: Boolean);


    procedure OnReceived (ASender: TComponent; const AText, AData: string);
    procedure OnSent     (ASender: TComponent; const AText, AData: string);
    procedure OnStatus   (ASender: TComponent; const AText: string);
  protected
    function  &Do (AMethod: TMethod; const AUri: TURI; ASource, AResponse: TStream;
                   const AContentType: string = 'application/json; charset=UTF-8'): Integer; overload;
  public
    function  DoStream (AMethod: TMethod; const AUri: TURI;
                   const ASource: TStream; out AResponse: ISuperObject;
                   const AContentType: string = 'application/json; charset=UTF-8'): Integer;
    function  &Do (AMethod: TMethod; const AUri: TURI;
                   const ASource: ISuperObject; out AResponse: ISuperObject;
                   const AContentType: string = 'application/json; charset=UTF-8'): Integer; overload;
    function  &Do (AMethod: TMethod; const AUri: TURI; const ASource: ISuperObject;
                   const AContentType: string = 'application/json; charset=UTF-8'): Integer; overload;
    function  &Do (AMethod: TMethod; const AUri: TURI;
                   const ASource: ISuperObject; out AResponse: TStream;
                   const AContentType: string = 'application/json; charset=UTF-8'): Integer; overload;

    function Authorize(const AFindToken: TOnFindToken): Boolean;
  public
    constructor Create;
    destructor Destroy; override;
  public
    property Headers    : TIdHeaderList read getCustomHeaders;
    property ContentType: string read getContentType write setContentType;
    property AuthCode   : string read FAuthCode write setAuthCode;
    property AuthorizeParams: TStrings read FAuthorizeParams;
    property LastError: string read FLastError;
  end;


  TCloudsPath = class

  const
    CS_PathSeparator = '/';
  public
    class function Combine(const APath1, APath2: string): string;
    class function PathToCloudsPath (const ARootPath, APath: string): string;
    class function GetFileName      (const APath: string; const ASeparator: Char = CS_PathSeparator): string;
    class function GetDirectoryName (const APath: string; const ASeparator: Char = CS_PathSeparator): string;
  end;


  TOAuth2ResponseTypeHelper = record helper for TOAuth2ResponseType

  public

    class function FromString(const AValue: string): TOAuth2ResponseType; static;

    function ToString: string;

  end;


implementation

type
  TMethodHelper = record helper for TRESTClient.TMethod
  public
    function ToString: string;
  end;

{ TClient }

function TRESTClient.DoStream(AMethod: TMethod; const AUri: TURI;
  const ASource: TStream; out AResponse: ISuperObject;
  const AContentType: string): Integer;
var
  LOutput: TStream;
begin
  LOutput := TMemoryStream.Create;
  try
    Result := &Do(AMethod, AUri, ASource, LOutput, AContentType);
    AResponse := StreamToJSon(LOutput);
  finally
    FreeAndNil(LOutput);
  end;
end;

function TRESTClient.Authorize(const AFindToken: TOnFindToken): Boolean;
var
  wv: Tfrm_OAuthWebForm;
  LOAuth2  : TOAuth2Authenticator;
  LDone    : Boolean;
  LShowWait: Boolean;
begin
  FOnFindToken := AFindToken;
//  FLastError := '';
  Result := ( not AuthCode.IsEmpty );
  if ( not Result ) or
     ( FNeedAuthorize )  then
  begin
    LOAuth2 := TOAuth2Authenticator.Create(nil);
    try
      LOAuth2.AuthorizationEndpoint := AuthorizeParams.Values['AuthorizationEndpoint'];
      LOAuth2.AccessTokenEndpoint   := AuthorizeParams.Values['AccessTokenEndpoint'];
      LOAuth2.RedirectionEndpoint   := AuthorizeParams.Values['RedirectionEndpoint'];
      LOAuth2.Scope                 := AuthorizeParams.Values['Scope'];
      LOAuth2.ClientID              := AuthorizeParams.Values['ClientID'];
      LOAuth2.ClientSecret          := AuthorizeParams.Values['ClientSecret'];
      LOAuth2.ResponseType          := TOAuth2ResponseType.FromString(AuthorizeParams.Values['ResponseType']);
      LOAuth2.TokenType             := TOAuth2TokenType.ttNONE;
//      DoLog('Start Craft Token');
      wv := Tfrm_OAuthWebForm.Create(nil);
      try
        wv.OnAfterRedirect  := self.OAuth2_DropBox_OnAfterRedirect;
        wv.OnBeforeRedirect := self.OAuth2_DropBox_OnAfterRedirect;
        wv.OnTitleChanged   := OAuth2_GoogleDrive_BrowserTitleChanged;
//        wv.OnError := WebBrowserError;
        wv.ShowModalWithURL(LOAuth2.AuthorizationRequestURI);
      finally
        wv.Free;
      end;
//      Result := FToken <> '';

      if ( not AuthCode.IsEmpty ) and
         ( not LOAuth2.AccessTokenEndpoint.IsEmpty ) then
      begin
        LOAuth2.AuthCode := AuthCode;
        LOAuth2.ChangeAuthCodeToAccesToken;
        AuthCode := LOAuth2.AccessToken;
      end;
      Result := ( not AuthCode.IsEmpty );
    except
      on E: Exception do
      begin
        FLastError := e.Message;
//        Logger.WriteLogException('TRESTClient.Authorize', E);
        Result := false;
      end;
    end;
  end;
end;

constructor TRESTClient.Create;
var
  LSSL: TIdSSLIOHandlerSocketOpenSSL;
  LLog: TIdLogEvent;
begin
  FIdHTTP := TIdHTTP.Create(nil);
  LLog := TIdLogEvent.Create(FIdHTTP);
  LSSL := TIdSSLIOHandlerSocketOpenSSL.Create(FIdHTTP);
  FIdHTTP.Intercept := LLog;
  FIdHTTP.IOHandler := LSSL;
  LLog.OnStatus := OnStatus;
  LLog.OnReceived := OnReceived;
  LLog.OnSent := OnSent;
  LLog.Active := True;
  FAuthorizeParams := TStringList.Create;
end;

destructor TRESTClient.Destroy;
begin
  FreeAndNil(FAuthorizeParams);
  inherited;
end;

function TRESTClient.getContentType: string;
begin
  Result := fIdHTTP.Request.ContentType;
end;

function TRESTClient.GetCustomHeaders: TIdHeaderList;
begin
  Result := fIdHTTP.Request.CustomHeaders;
end;

function TRESTClient.JSonToStream(const AJSon: ISuperObject): TStream;
begin
  if ( AJSon <> nil ) then
    Result := TStringStream.Create(AJSon.AsJSon())
  else
    Result := nil;
end;

procedure TRESTClient.OAuth2_DropBox_OnAfterRedirect(const AURL: string;
  var DoCloseWebView: boolean);
begin
  if Assigned(FOnFindToken) then
    DoCloseWebView := FOnFindToken(AURL);
end;

procedure TRESTClient.OAuth2_DropBox_OnFailLoadWithError(ASender: TObject;
  StatusCode: OleVariant; var Cancel: Boolean);
begin
  if ( VarIsOrdinal(StatusCode) and StatusCode > 0 ) then
    Cancel := true
  else
    Cancel := false;
end;

procedure TRESTClient.OAuth2_GoogleDrive_BrowserTitleChanged(
  const ATitle: string; var DoCloseWebView: boolean);
begin
  if Assigned(FOnFindToken) then
    DoCloseWebView := FOnFindToken(ATitle);
end;

procedure TRESTClient.OnReceived(ASender: TComponent; const AText, AData: string);
begin
//
end;

procedure TRESTClient.OnSent(ASender: TComponent; const AText, AData: string);
begin
//
end;

procedure TRESTClient.OnStatus(ASender: TComponent; const AText: string);
begin
//
end;

function TRESTClient.&Do(AMethod: TMethod; const AUri: TURI; const ASource: ISuperObject;
  out AResponse: TStream; const AContentType: string): Integer;
var
  LInput : TStream;
begin
  LInput := JSonToStream(ASource);
  try
    AResponse := TMemoryStream.Create;
    Result := &Do(AMethod, AUri, LInput, AResponse, AContentType);
  finally
    FreeAndNil(LInput);
  end;
end;

function TRESTClient.&Do(AMethod: TMethod; const AUri: TURI; const ASource: ISuperObject;
  const AContentType: string): Integer;
var
  LInput : TStream;
begin
  LInput := JSonToStream(ASource);
  try
    Result := &Do(AMethod, AUri, LInput, nil, AContentType);
  finally
    FreeAndNil(LInput);
  end;
end;

function TRESTClient.&Do(AMethod: TMethod; const AUri: TURI; ASource, AResponse: TStream;
  const AContentType: string): Integer;
var
  LStream: TStream;
  LJson  : ISuperObject;
  LErrorBody: string;
begin
  Result := 0;
  FLastError := '';
  fIdHTTP.Request.ContentType := AContentType;
  fIdHTTP.Request.CustomHeaders.Values['Authorization'] := 'Bearer '+AuthCode;
  fIdHTTP.Request.CustomHeaders.Values['Accept-Charset'] := 'utf-8';
  LStream := ASource;
  LErrorBody := '';
  if ASource = nil then
    LStream := TMemoryStream.Create;

  try
    try
      fIdHTTP.DoRequest(AMethod.ToString, AUri.URI, LStream, AResponse, []);
      Result := fIdHTTP.ResponseCode;
      if Result <> 200 then
      begin
        LJson := StreamToJSon(AResponse);
        if LJson <> nil then
          LErrorBody := LJson.AsJSon();

        //DoLog('TRESTClient.Post: %d, %s, body: %s', [Result, fIdHTTP.ResponseText, LErrorBody], lsvError);
      end;
    except
      on e: EIdHTTPProtocolException do
      begin
        FLastError := E.Message;
        Result := e.ErrorCode;
        LJson := StreamToJSon(AResponse);
        if LJson <> nil then
          LErrorBody := LJson.AsJSon();
        //Logger.WriteLogFmr('TRESTClient.Post %d, %s, body: %s', [e.ErrorCode, E.Message, LErrorBody], lsvError);
      end;
      on e: Exception do
      begin
        FLastError := E.Message;
        Result := 500;
        if not fIdHTTP.Connected then
          AuthCode := string.Empty;
        //Logger.WriteLogFmr('TRESTClient.Post %s', [E.Message], lsvError);
      end;
    end;
  finally
    if Result = 401 then  //Bad or expired token.
      AuthCode := string.Empty;
    fIdHTTP.Request.CustomHeaders.Clear;
    if ASource = nil then
      FreeAndNil(LStream);
  end;
end;

function TRESTClient.&Do(AMethod: TMethod; const AUri: TURI; const ASource: ISuperObject;
  out AResponse: ISuperObject; const AContentType: string): Integer;
var
  LOutput: TStream;
begin
  try
    Result := &Do(AMethod, AUri, ASource, LOutput, AContentType);
    if ( Result = 200 ) then
      AResponse := StreamToJSon(LOutput);
  finally
    FreeAndNil(LOutput);
  end;
end;

procedure TRESTClient.SetAuthCode(const Value: string);
begin
  FAuthCode := Value;
end;

procedure TRESTClient.setContentType(const AValue: string);
begin
  fIdHTTP.Request.ContentType := AValue;
end;

function TRESTClient.StreamToJSon(AStream: TStream): ISuperObject;
var
  LBuff: TBytes;
  LStr : string;
begin
  Result := SO;
  if ( AStream <> nil ) and
     ( AStream.Size > 0 ) then
    try
      SetLength(LBuff, AStream.Size);
      AStream.Seek(0, 0);
      AStream.Read(LBuff, AStream.Size);
      LStr := TEncoding.UTF8.GetString(LBuff);
      Result := SO(LStr);
    except
    end;
end;

{ TOAuth2ResponseTypeHelper }

class function TOAuth2ResponseTypeHelper.FromString(
  const AValue: string): TOAuth2ResponseType;
begin
  Result := TOAuth2ResponseType(GetEnumValue(TypeInfo(TOAuth2ResponseType), AValue));
end;

function TOAuth2ResponseTypeHelper.ToString: string;
begin
  Result := GetEnumName(TypeInfo(TOAuth2ResponseType), Integer(Self));
end;

{ TMethodHelper }

function TMethodHelper.ToString: string;
begin
  case Self of
    POST   : Result := Id_HTTPMethodPost;
    PUT    : Result := Id_HTTPMethodPut;
    DELETE : Result := Id_HTTPMethodDelete;
    PATCH  : Result := Id_HTTPMethodPatch;
  else
    Result := Id_HTTPMethodGet;
  end;
end;

{ TRESTClient.TURI }

class operator TRESTClient.TURI.Add(const A: TURI; B: string): TURI;
begin
  Result := A;
  Result.AddPath(B);
end;

procedure TRESTClient.TURI.AddParam(const AName, AValue: string);
begin
  FParams := FParams + [TPair<string, string>.Create(AName, AValue)];
end;

procedure TRESTClient.TURI.AddPath(const APath: string);
begin
  FURI := TCloudsPath.Combine(FURI, APath);
end;

class operator TRESTClient.TURI.Explicit(const Value: string): TURI;
begin
  Result.FURI := Value;
end;

function TRESTClient.TURI.getURI: string;

  function getParams: string;
  var
    LParam: TPair<string, string>;
  begin
    for LParam in FParams do
      Result := Result + '&' + URIEncode(LParam.Key) + '=' + URIEncode(LParam.Value);
    Result := Result.Trim(['&']);
  end;

var
  LUri: TIdURI;
  LStr: string;
  LParams: string;
begin
  LParams := getParams;
  LStr := FURI;
  if ( not LParams.IsEmpty ) then
    LStr := LStr + '?' + LParams;

  LUri := TIdURI.Create(LStr);
  try
    LUri.Path := TIdURI.PathEncode(LUri.Path);

    LUri.Document := TIdURI.PathEncode(LUri.Document);

//    LUri.Params := TNetEncoding.URL.Encode(LUri.Params);

    Result := LUri.URI;
  finally
    LUri.Free;
  end;
end;

class operator TRESTClient.TURI.Implicit(const Value: string): TURI;
begin
  Result.FURI := Value;
end;

procedure TRESTClient.TURI.SetParam(const AName, AValue: string);
var
  i: Integer;
begin
  for i := 0 to Length(FParams) -1 do
    if ( FParams[i].Key = AName ) then
    begin
      FParams[i].Value := AValue;
      Exit;
    end;
  AddParam(AName, AValue);
end;

{ TCloudsPath }

class function TCloudsPath.Combine(const APath1, APath2: string): string;
var
  Ch: Char;
begin
  if ( APath1 = '' ) then
    Result := APath2
  else
    if ( APath2 = '' ) then // DO NOT LOCALIZE
      Result := APath1
    else begin
      Ch := APath1[High(APath1)];
      if ( Ch <> CS_PathSeparator ) then
        Result := APath1 + CS_PathSeparator + APath2
      else
        Result := APath1 + APath2;
    end;
end;

class function TCloudsPath.GetDirectoryName(const APath: string;
  const ASeparator: Char): string;
begin
  Result := Copy(APath, 1, APath.LastDelimiter(ASeparator)+1);
end;

class function TCloudsPath.GetFileName(const APath: string;
  const ASeparator: Char): string;
begin
  Result := Copy(APath, APath.LastDelimiter(ASeparator)+2, Length(APath));
end;

class function TCloudsPath.PathToCloudsPath(const ARootPath, APath: string): string;
begin
  Result := CS_PathSeparator + APath.Replace(ARootPath, '',  [rfIgnoreCase]).Replace(TPath.DirectorySeparatorChar, CS_PathSeparator);
end;

end.
