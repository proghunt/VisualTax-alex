object frm_OAuthWebForm: Tfrm_OAuthWebForm
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  Caption = 'OAuth Web-Login'
  ClientHeight = 687
  ClientWidth = 583
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  OnClose = FormClose
  OnCreate = FormCreate
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object pnlBottom: TPanel
    Left = 0
    Top = 632
    Width = 583
    Height = 55
    Align = alBottom
    TabOrder = 0
    ExplicitWidth = 581
    DesignSize = (
      583
      55)
    object Bevel1: TBevel
      Left = 8
      Top = 14
      Width = 567
      Height = 2
      Anchors = [akLeft, akRight, akBottom]
      ExplicitTop = 295
      ExplicitWidth = 619
    end
    object Label1: TLabel
      Left = 11
      Top = 27
      Width = 477
      Height = 13
      Anchors = [akLeft, akBottom]
      Caption = 
        'This windows will close automatically when a token could be dete' +
        'cted and extracted.'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      OnClick = Label1Click
    end
    object btn_Close: TButton
      Left = 500
      Top = 22
      Width = 75
      Height = 25
      Anchors = [akRight, akBottom]
      Caption = 'Close'
      ModalResult = 8
      TabOrder = 0
      ExplicitLeft = 498
    end
  end
  object ChromiumWindow: TChromiumWindow
    Left = 0
    Top = 0
    Width = 583
    Height = 632
    Align = alClient
    TabOrder = 1
    OnAfterCreated = ChromiumWindowAfterCreated
    ExplicitLeft = 160
    ExplicitTop = 288
    ExplicitWidth = 100
    ExplicitHeight = 41
  end
  object TimerChromium: TTimer
    Enabled = False
    Interval = 100
    OnTimer = TimerChromiumTimer
    Left = 200
    Top = 472
  end
end
